# 4thYear_AI_CA1

Known Issues:
- Missiles not working, causes by Circular Dependancy
- Doesn't interact with other entities
- Wander functions can be stuck in the walls
- Predator doesnt move 

Job Split 50/50:
Jack Fennell
- Predators
- Workers
- Nest
- Power Ups

Eoin Abbey-Maher
- Radar
- Sweeper Bots
- Map/World Layout
- Player
- Collisions

