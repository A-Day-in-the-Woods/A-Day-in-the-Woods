#ifndef GLOBAL_H
#define GLOBAL_H

#include <iostream>
#include <SFML/Graphics.hpp>
#include <map>
struct GlobalSettings {
	unsigned static const int s_width{ 1080 };
	unsigned static const int s_height{ 1080 };

};

#endif // !GLOBAL_H