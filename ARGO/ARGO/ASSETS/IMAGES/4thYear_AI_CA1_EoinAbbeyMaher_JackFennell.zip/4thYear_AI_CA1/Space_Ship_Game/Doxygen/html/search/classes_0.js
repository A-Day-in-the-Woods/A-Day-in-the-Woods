var searchData=
[
  ['game_89',['Game',['../class_game.html',1,'']]],
  ['globalsettings_90',['GlobalSettings',['../struct_global_settings.html',1,'']]]
];
