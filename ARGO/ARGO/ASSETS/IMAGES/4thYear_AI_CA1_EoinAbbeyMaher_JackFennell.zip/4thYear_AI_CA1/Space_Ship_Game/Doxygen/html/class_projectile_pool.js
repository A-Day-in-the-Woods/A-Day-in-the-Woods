var class_projectile_pool =
[
    [ "ProjectilePool", "class_projectile_pool.html#a2f838007dbfd7c92eae87532a4cd5dc4", null ],
    [ "create", "class_projectile_pool.html#a5ca16f6a6caa3f5479fd6fa5117a6e2f", null ],
    [ "getActive", "class_projectile_pool.html#afab5b10ff9392283cb0beffad3e37357", null ],
    [ "render", "class_projectile_pool.html#a851930841f2cd465f476d8489d30a498", null ],
    [ "update", "class_projectile_pool.html#a1665188086b0c6d8aeb6bfa15931ae9b", null ],
    [ "m_projectiles", "class_projectile_pool.html#a9f2fc5e6f5732ad8502155cebd614628", null ]
];