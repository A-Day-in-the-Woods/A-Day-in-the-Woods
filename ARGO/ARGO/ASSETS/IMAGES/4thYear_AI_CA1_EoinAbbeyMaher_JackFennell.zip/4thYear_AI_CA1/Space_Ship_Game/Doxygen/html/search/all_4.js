var searchData=
[
  ['game_9',['Game',['../class_game.html',1,'Game'],['../class_game.html#ad59df6562a58a614fda24622d3715b65',1,'Game::Game()']]],
  ['game_2eh_10',['Game.h',['../_game_8h.html',1,'']]],
  ['getactive_11',['getActive',['../class_projectile_pool.html#afab5b10ff9392283cb0beffad3e37357',1,'ProjectilePool']]],
  ['getnewposition_12',['getNewPosition',['../class_game.html#addd81c61e7a05976413ba505e5ba7cf3',1,'Game']]],
  ['getposition_13',['getPosition',['../class_missile.html#ad07ea218b8c2b6e7f52c78095a978340',1,'Missile']]],
  ['global_2eh_14',['Global.h',['../_global_8h.html',1,'']]],
  ['globalsettings_15',['GlobalSettings',['../struct_global_settings.html',1,'']]]
];
