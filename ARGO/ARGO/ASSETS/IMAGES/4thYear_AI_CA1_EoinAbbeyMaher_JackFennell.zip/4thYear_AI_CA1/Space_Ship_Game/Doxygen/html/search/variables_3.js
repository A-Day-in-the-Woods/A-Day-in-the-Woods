var searchData=
[
  ['s_5fheight_175',['s_height',['../struct_global_settings.html#a24f63a5efb17c01148a25526182d5d62',1,'GlobalSettings']]],
  ['s_5fpool_5fsize_176',['s_POOL_SIZE',['../class_projectile_pool.html#a3e5865d1bde7e70c620bb8ad0019d2c4',1,'ProjectilePool']]],
  ['s_5ftime_5fbetween_5fshots_177',['s_TIME_BETWEEN_SHOTS',['../class_player.html#a720634a6eb0f9847a1c4196322aaff66',1,'Player']]],
  ['s_5fwidth_178',['s_width',['../struct_global_settings.html#a1c5ee0bd44f69e3060ba412f79087df7',1,'GlobalSettings']]]
];
