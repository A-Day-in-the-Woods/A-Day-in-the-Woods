var class_worker =
[
    [ "Worker", "class_worker.html#a3754817df06ffe220f7f0d903c78ccac", null ],
    [ "~Worker", "class_worker.html#aa8e4543ef1e93fd9d884269ba30c5bfe", null ],
    [ "render", "class_worker.html#afd985b531acdd1c799d571cab95423e6", null ],
    [ "setBody", "class_worker.html#a38591ab0cca7d718aba5bfb73aa4ea14", null ],
    [ "update", "class_worker.html#a20c002ca69b72a663bdd8c31273bfc7c", null ]
];