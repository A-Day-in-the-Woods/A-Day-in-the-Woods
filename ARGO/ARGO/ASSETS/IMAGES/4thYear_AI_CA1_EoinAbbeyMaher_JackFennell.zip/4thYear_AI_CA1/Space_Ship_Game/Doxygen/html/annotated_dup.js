var annotated_dup =
[
    [ "Game", "class_game.html", "class_game" ],
    [ "GlobalSettings", "struct_global_settings.html", null ],
    [ "Missile", "class_missile.html", "class_missile" ],
    [ "Nest", "class_nest.html", "class_nest" ],
    [ "Player", "class_player.html", "class_player" ],
    [ "Predator", "class_predator.html", "class_predator" ],
    [ "ProjectilePool", "class_projectile_pool.html", "class_projectile_pool" ],
    [ "RoomBuilder", "class_room_builder.html", "class_room_builder" ],
    [ "Sweeper", "class_sweeper.html", "class_sweeper" ],
    [ "Tile", "class_tile.html", "class_tile" ],
    [ "Worker", "class_worker.html", "class_worker" ]
];