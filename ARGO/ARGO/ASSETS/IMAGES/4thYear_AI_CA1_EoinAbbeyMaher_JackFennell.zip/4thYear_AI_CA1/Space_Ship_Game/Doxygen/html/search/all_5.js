var searchData=
[
  ['init_16',['init',['../class_missile.html#a221be2611f746956b826aaef717bd201',1,'Missile::init()'],['../class_sweeper.html#a653d63bce2845994b40a9ac7cdc5e657',1,'Sweeper::init()'],['../class_tile.html#acf065eb802301984294eac5617bb8916',1,'Tile::init()']]],
  ['inuse_17',['inUse',['../class_missile.html#aa9d50d3c3c1fd8096df10987fe4d2b1f',1,'Missile']]],
  ['isdead_18',['isDead',['../class_sweeper.html#aa10d5322cc52e4ef55bac40f7690a67d',1,'Sweeper']]]
];
