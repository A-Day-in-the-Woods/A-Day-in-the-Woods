var class_predator =
[
    [ "Predator", "class_predator.html#a29bbe30ba8b0891daeb1495c1313ebd6", null ],
    [ "~Predator", "class_predator.html#a9ef1a4a3a5988d1d1e5844a235b36b8b", null ],
    [ "checkCollisions", "class_predator.html#aaf1fa50565ee5f44119ee06c17ae5b2b", null ],
    [ "move", "class_predator.html#ac387f969b16cf3651b097f4470368683", null ],
    [ "render", "class_predator.html#a4c56d9d79c3900d48cf469136b0c0c3d", null ],
    [ "searchForPlayer", "class_predator.html#a0505fdde789528cda99c46b0a17c0aed", null ],
    [ "setBody", "class_predator.html#a27ca919554f1ad0e17964d88da19d0df", null ],
    [ "update", "class_predator.html#acc3fd3873388d9ad0f81ba52f50233be", null ]
];