var searchData=
[
  ['worker_145',['Worker',['../class_worker.html#a3754817df06ffe220f7f0d903c78ccac',1,'Worker']]]
];
