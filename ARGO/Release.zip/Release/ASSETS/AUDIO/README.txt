
== File naming scheme ==

Main Story : s_

Misc Story : w_

Tiles : t_

Music : m_

SFX : f_